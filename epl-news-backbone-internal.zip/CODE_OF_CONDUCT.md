# Team Code of Conduct (Internal)

- Be respectful, be concise, document decisions.
- Prefer async updates in PRs and issues; summarize meetings in `/docs/meeting-notes/`.