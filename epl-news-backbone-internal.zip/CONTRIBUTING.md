# Contributing (Internal)

- Target branch: `main` (protected). Submit PRs from `feat/*`, `fix/*`, or `data/*` branches.
- Small PRs with clear descriptions. Link to issue/task.
- Run `make check` and `make test` locally before pushing.
- Request review from at least one teammate. Squash & merge after approval.

## Commit style
Use conventional commits:
- `feat: ...`, `fix: ...`, `docs: ...`, `chore: ...`, `refactor: ...`, `test: ...`