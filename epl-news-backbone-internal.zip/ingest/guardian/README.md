# Guardian Ingestion (dev key, ~500 calls/day)

- Configure `GUARDIAN_API_KEY` in `.env`.
- Example run:
  ```bash
  python ingest/guardian/guardian_pull.py --from 2016-01-01 --to 2016-12-31 --section football --out data/guardian
  ```