# GDELT (BigQuery) GKG Pull

- Requires GCP auth and `GCP_PROJECT` in `.env`.
- See SQL skeleton in `infra/bq/bq_gkg_pull.sql`.