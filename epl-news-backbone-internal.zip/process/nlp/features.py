from dataclasses import dataclass
from typing import List, Dict

@dataclass
class ArticleFeatures:
    article_id: str
    club_keys: List[str]
    stance_score: float
    sentiment: float
    topics: List[str]

def featurize(text: str) -> ArticleFeatures:
    # TODO: hook up spaCy + stance regex + sentiment
    return ArticleFeatures(article_id="demo", club_keys=[], stance_score=0.0, sentiment=0.0, topics=[])