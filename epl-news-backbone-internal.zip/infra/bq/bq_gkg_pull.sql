-- Standard SQL
-- Parameterize date ranges via scheduler vars if desired.

CREATE OR REPLACE TABLE `${project}.${dataset}.gkg_hits_2016_2025`
PARTITION BY DATE
AS
SELECT
  GKGRECORDID,
  DATE,
  DocumentIdentifier,
  V2Themes,
  AllNames,
  V2Tone,
  SourceCommonName,
  Languages
FROM `gdelt-bq.gdeltv2.gkg_partitioned`
WHERE DATE BETWEEN '2016-01-01' AND '2025-12-31'
  AND (
    REGEXP_CONTAINS(AllNames, r'(Premier League)')
    OR REGEXP_CONTAINS(AllNames, r'(Arsenal|Chelsea|Liverpool|Manchester City|Manchester United|Tottenham|Newcastle|Aston Villa|Brighton|West Ham|Leicester|Wolves|Everton|Southampton|Leeds|Crystal Palace|Brentford|Bournemouth|Nottingham Forest|Fulham)')
  );