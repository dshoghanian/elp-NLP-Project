# EPL News + Context Backbone (Internal)

> Internal, private repository for our group project. Do **not** share outside the team.

This repo scaffolds a reproducible pipeline to ingest football news (Guardian, GDELT), normalize & dedupe articles, run basic NLP (entities, stance, sentiment/topics), and join to fixtures/attendance for downstream analyses (e.g., rumor credibility and demand nowcasting).

## Quickstart

### 1) Clone and create env
```bash
git clone <your-private-remote> epl-news-backbone
cd epl-news-backbone
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -U pip
pip install -r requirements.txt
```

### 2) Configure secrets
Copy `.env.example` to `.env` and fill values (Guardian key, GCP project/bucket, etc.). **Never commit real keys.**

### 3) Run local smoke tests
```bash
make check           # lint + type check
make test            # unit tests (fast)
```

### 4) First data pull (dry-run)
See `/ingest/guardian/README.md` and `/ingest/gdelt/README.md` for command examples. Raw outputs land in your configured GCS bucket or local `data/` if GCS not set.

## Monorepo layout

```
/ingest/         # source-specific pullers (Guardian, GDELT, FBref)
/process/        # dedupe, normalization, NLP
/model/          # notebooks and training scripts
/infra/          # deploy and scheduled jobs (Cloud Run, Scheduler, BQ)
/docs/           # project docs (data dictionary, provenance, runbook)
/. github/       # CI, PR templates
```

Suggested branch names: `feat/<area>`, `fix/<area>`, `data/<source>`. Protect `main`, require PR.

## Data governance (internal)

- Keep raw data out of git. Use GCS buckets or local `data/` (gitignored).
- Respect source ToS (Guardian/GDELT allowed, no scraping of X/Reddit).
- Track provenance in `/docs/provenance.md` and schema in `/docs/data_dictionary.md`.

## Attributions & context
High-level goals and steps are summarized from our Executive Summary and Data Collection Steps stored in `/docs`. See those docs for full context.