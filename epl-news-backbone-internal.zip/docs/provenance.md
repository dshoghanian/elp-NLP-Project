# Data Provenance & ToS Notes

- Guardian: Open Platform (dev key, rate limits)
- GDELT: BigQuery public dataset
- FBref: fixtures/attendance (respect robots/ToS; avoid scraping)