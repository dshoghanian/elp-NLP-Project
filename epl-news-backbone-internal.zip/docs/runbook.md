# Runbook

- Nightly Cloud Scheduler triggers Cloud Run for guardian pull.
- BigQuery scheduled query refresh for GDELT.
- Re-run pipelines idempotently with last checkpoint.