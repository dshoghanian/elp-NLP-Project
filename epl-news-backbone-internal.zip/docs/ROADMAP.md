# Roadmap

- v0: ingestion + basic NLP
- v1: rumor objects + joins + EDA
- v2: models + app