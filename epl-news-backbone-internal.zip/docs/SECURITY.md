# Security

- Do not commit secrets. Use `.env` locally and GCP Secret Manager in prod.